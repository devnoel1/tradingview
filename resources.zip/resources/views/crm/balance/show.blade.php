@extends('adminlte::page')

@section('title', 'Dashboard')

@section('content_header')
    <h1>CRM - Balance</h1>
@stop

@section('content')
    <div class="card">
        <div class="card-header">
            <h3 class="card-title">Balance Transaction</h3>
        </div>
        <div class="card-body">
            <dl class="row">
                <dt class="col-sm-4">Name</dt>
                <dd class="col-sm-8">{{$user->name}}</dd>
                <dt class="col-sm-4">Email</dt>
                <dd class="col-sm-8">{{$user->email}}</dd>
                <dt class="col-sm-4">Type</dt>
                <dd class="col-sm-8">{{$balance->action}}</dd>
                <dt class="col-sm-4">Wallet</dt>
                <dd class="col-sm-8">{{$balance->wallet->name}}</dd>
                <dt class="col-sm-4">Amount</dt>
                <dd class="col-sm-8">{{$balance->amount}}</dd>
                @if(isset($balance->note))
                    <dt class="col-sm-4">Note</dt>
                    <dd class="col-sm-8">{{$balance->note}}</dd>
                @endif
            </dl>
        </div>
        <div class="card-footer">
            <a href="{{route('crm.balance.approve', ['balance' => $balance->id])}}" class="btn btn-info float-right">Approve</a>
        </div>
    </div>

@stop

@section('css')
    <link rel="stylesheet" href="/css/admin_custom.css">
@stop

@section('js')

@stop
