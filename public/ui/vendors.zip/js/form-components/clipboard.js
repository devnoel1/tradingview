// Forms Clipboard

$(document).ready(() => {
  new ClipboardJS(".clipboard-trigger");
});
