@extends('adminlte::page')

@section('title', 'Dashboard')

@section('content_header')
    <h1>CRM - Account</h1>
@stop

@section('content')
    <div class="card">
        <div class="card-header">
            <h3 class="card-title">Edit a Account</h3>
        </div>
        <form class="form-horizontal" method="POST" action="{{route('crm.account.update', ['account' => $account->id])}}">
            @method('patch')
            @csrf
            <div class="card-body">
                <div class="form-group row">
                    <label for="inputName" class="col-sm-2 col-form-label">Fullname</label>
                    <div class="col-sm-10">
                        <input type="text" name="name" class="form-control" id="inputName" placeholder="Name" value="{{$account->name}}" required>
                    </div>
                </div>
                <div class="form-group row">
                    <label for="inputEmail" class="col-sm-2 col-form-label">Email</label>
                    <div class="col-sm-10">
                        <input type="email" name="email" class="form-control" id="inputEmail" placeholder="Email" value="{{$account->email}}"  required>
                    </div>
                </div>
                <hr/>
                <div class="form-group row">
                    <label for="inputAddressLine1" class="col-sm-2 col-form-label">Address Line 1</label>
                    <div class="col-sm-10">
                        <input type="text" name="address_line_1" class="form-control" id="inputAddressLine1" placeholder="Address Line 1" value="{{$account->userProfile->address_line_1}}" required>
                    </div>
                </div>
                <div class="form-group row">
                    <label for="inputAddressLine2" class="col-sm-2 col-form-label">Address Line 2</label>
                    <div class="col-sm-10">
                        <input type="text" name="address_line_2" class="form-control" id="inputAddressLine2" placeholder="Address Line 2" value="{{$account->userProfile->address_line_2}}">
                    </div>
                </div>
                <div class="form-group row">
                    <label for="inputZipcode" class="col-sm-2 col-form-label">Zipcode</label>
                    <div class="col-sm-10">
                        <input type="text" name="zipcode" class="form-control" id="inputZipcode" placeholder="Zipcode" value="{{$account->userProfile->zipcode}}" required>
                    </div>
                </div>
                <div class="form-group row">
                    <label for="inputCity" class="col-sm-2 col-form-label">City</label>
                    <div class="col-sm-10">
                        <input type="text" name="city" class="form-control" id="inputCity" placeholder="City" value="{{$account->userProfile->city}}" required>
                    </div>
                </div>
                <div class="form-group row">
                    <label for="inputState" class="col-sm-2 col-form-label">State</label>
                    <div class="col-sm-10">
                        <input type="text" name="state" class="form-control" id="inputState" placeholder="State" value="{{$account->userProfile->state}}" required>
                    </div>
                </div>
                <div class="form-group row">
                    <label for="inputCountry" class="col-sm-2 col-form-label">Counrty</label>
                    <div class="col-sm-10">
                        <input type="text" name="country" class="form-control" id="inputCountry" placeholder="Country" value="{{$account->userProfile->country}}" required>
                    </div>
                </div>
                <div class="form-group row">
                    <label for="inputExchange" class="col-sm-2 col-form-label">Level</label>
                    <div class="col-sm-10">
                        <select class="form-control" name="level" required>
                            @foreach ($levels as $level)
                                <option value="{{ $level->id }}" {{ ( $level->id == $account->userProfile->level_id) ? 'selected' : '' }} > {{ $level->name }} </option>
                            @endforeach
                        </select>
                    </div>
                </div>
            </div>
            <!-- /.card-body -->
            <div class="card-footer">
                <button type="submit" class="btn btn-info">Update</button>
                <a href="{{route('crm.account.index')}}" class="btn btn-default float-right">Cancel</a>
            </div>
            <!-- /.card-footer -->
        </form>
    </div>

@stop

@section('css')
    <link rel="stylesheet" href="/css/admin_custom.css">
@stop

@section('js')

@stop
