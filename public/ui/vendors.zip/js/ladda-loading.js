// Ladda loading buttons

$(document).ready(() => {
  Ladda.bind(".ladda-button", { timeout: 2000 });
});
