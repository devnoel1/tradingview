<div>
    <main class="flex absolute w-full h-full">
        <div class="min-h-full bg-gray-900 flex overflow-hidden flex-col w-full h-full">

            <div class="flex flex-auto flex-col overflow-hidden flex-1">
                <div class="overflow-hidden flex flex-auto flex-col flex-1">
                    <div class="grid xl:grid-cols-6 2xl:grid-cols-7 gap-0 bg-gray-900 flex flex-col flex-1 b-t overflow-hidden">


                        <div class="grid col-start-1 col-end-3 2xl:col-end-1 hidden xl:flex bg-gray-800 flex-col flex-1 overflow-hidden">
                            <div class="wallet inner grid grid-cols-2 items-center justify-between flex overflow-hidden">
                                <div class="col-start-1 col-end-1">
                                    <em class="flex">All Portfolios</em>
                                    <sub class="flex">&euro; {{round($total_value, 2)}}</sub>
                                </div>
                                <div class="col-start-2 col-end-2 text-right">
                                    @if(sizeof($wallets) < 5)
                                        <a class="grey--button open-modal" data-modal-id="modal-create" wire:click="$toggle('addingWallet')">Create</a>
                                    @endif
                                </div>
                            </div>

                            @foreach($wallets as $wallet)
                                <div class="custom-scroll">
                                    <div class="wallet wallet-item @if($wallet->active)default @endif " wire:click="setView('{{$wallet->id}}')">
                                        <em wire:click="setActive('{{$wallet->id}}')">{{$wallet->name}} @if($wallet->active)<sup>active</sup>@endif
                                            @if($wallet->demo)
                                                <sup>demo</sup>
                                            @elseif($wallet->margin)
                                                <sup>margin</sup>
                                            @endif</em>
                                        <sub>&euro; @foreach($wallets_array as $wallet_object)@if($wallet_object['id'] == $wallet->id) {{round($wallet_object['total_value'], 2)}} @endif @endforeach</sub>
                                    </div>
                                </div>
                            @endforeach
                        </div>

                        <div class="xl:col-start-3 xl:col-end-7 2xl:col-start-2 2xl:col-end-8 overflow-hidden flex-1 flex-col flex xl:py-10 xl:px-10 2xl:py-20 2xl:px-10">
                            <div class="overflow-hidden flex flex-auto flex-col overflow-hidden flex-1 min-h-full max-h-full">
                                @foreach($wallets as $wallet)
                                    @if($wallet->id == $view_wallet_id)
                                        <div class="grid grid-cols-4 gap-0 bg-gray-900 flex flex-col flex-inital b-t overflow-hidden items-center px-4 xl:px-0 py-2 xl:py-0">
                                            <div class="col-start-1 col-end-5 xl:col-end-3 2xl:col-end-2">
                                                <div class="bg-grey-800 text-white flex flex-col flex-initial wallet--intro">
                                                    <div class="flex-row">
                                                        @if($wallet->active)
                                                            <sup class="flex-auto">active</sup>
                                                        @endif
                                                        @if($wallet->margin)
                                                            <sup class="flex-auto">margin</sup>
                                                        @endif
                                                        @if($wallet->demo)
                                                            <sup class="flex-auto">demo</sup>
                                                        @endif
                                                    </div>
                                                    <div class="flex-row">
                                                        <h2 wire:click="setActive('{{$wallet->id}}')">{{$wallet->name}}</h2>
                                                    </div>
                                                    <div class="grid grid-cols-3 gap-0 bg-gray-900 flex flex-col flex-1 b-t overflow-hidden flex-items mt-2">
                                                        <div class="text-2xl">&euro; @foreach($wallets_array as $wallet_object)@if($wallet_object['id'] == $wallet->id) {{round($wallet_object['total_value'], 2)}} @endif @endforeach</div>
                                                        <div class="">
                                                            <span class="block text-gray-600 text-xs">Holds on orders</span>
                                                            <span>&euro; @foreach($wallets_array as $wallet_object)@if($wallet_object['id'] == $wallet->id) {{round(($wallet_object['total_value'] - $wallet->balance), 2)}} @endif @endforeach</span>
                                                        </div>
                                                        <div class="">
                                                            <span class="block text-gray-600 text-xs">Available balance</span>
                                                            <span>&euro; {{round($wallet->balance, 2)}}</span>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                        </div>

                                        <div class="tab--system overflow-hidden flex flex-row mt-4">
                                            <a wire:click="setViewTab('open')" class="@if($view_tab == 'open')active @endif flex flex-col wallet-tab">
                                                <div class="flex flex-row items-center">
                                                    <svg width="24" height="24" viewBox="0 0 24 24" class="sc-gZMcBi cRiKgN"><g transform="translate(5 5)" stroke="#8a939f" fill="none" fill-rule="evenodd"><circle cx="7.5" cy="7.5" r="7.5"></circle><path d="M7.5 3.41V7.5l2.045 2.045"></path></g></svg>
                                                    <span class="text-white">Open</span>
                                                </div>
                                            </a>
                                            <a wire:click="setViewTab('filled')" class="@if($view_tab == 'filled')active @endif flex flex-col wallet-tab">
                                                <div class="flex flex-row items-center">
                                                    <svg width="24" height="24" viewBox="0 0 24 24" class="sc-gqjmRU kKmEpw"><g transform="translate(5 5)" stroke="#8a939f" fill="none" fill-rule="evenodd"><circle cx="7.5" cy="7.5" r="7.5"></circle><path d="M10.714 5.357L6.667 9.643 4.286 7.12"></path></g></svg>
                                                    <span class="text-white">Filled</span>
                                                </div>
                                            </a>
                                            <a wire:click="setViewTab('fees')" class="@if($view_tab == 'fees')active @endif flex flex-col wallet-tab">
                                                <div class="flex flex-row items-center">
                                                    <div class="flex flex-row items-center">
                                                        <svg width="24" height="24" viewBox="0 0 24 24" class="sc-VigVT dDjLRL"><g fill="#8a939f" fill-rule="nonzero" stroke="#8a939f" stroke-width="0.5"><path d="M14.902 12.902h-3.804V9.098A.098.098 0 0 0 11 9c-2.206 0-4 1.794-4 4s1.794 4 4 4 4-1.794 4-4a.098.098 0 0 0-.098-.098zM11 16.805A3.81 3.81 0 0 1 7.195 13a3.81 3.81 0 0 1 3.707-3.804V13c0 .054.044.098.098.098h3.804A3.81 3.81 0 0 1 11 16.805z"></path><path d="M13.095 7a.095.095 0 0 0-.095.095v3.81c0 .052.043.095.095.095h3.81a.095.095 0 0 0 .095-.095A3.91 3.91 0 0 0 13.095 7zm.095 3.81V7.192a3.72 3.72 0 0 1 3.618 3.618H13.19z"></path></g></svg>
                                                        <span class="text-white">Fees</span>
                                                    </div>
                                                </div>
                                            </a>
                                        </div>
                                        @if($view_tab == 'open')
                                            <div class="text-white flex flex-col flex-1 overflow-hidden mt-5 xl:mt-0">
                                                <div class="px-4 md:px-8 py-2 grid grid-cols-8 gap-2 bg-gray-800 text-white trade-history-header text-gray-700 uppercase semibold">
                                                    <div>Side</div>
                                                    <div>Market</div>
                                                    <div>Size</div>
                                                    <div>Filled</div>
                                                    <div>Price</div>
                                                    <div>Fee</div>
                                                    <div>Time</div>
                                                    <div>Status</div>
                                                </div>

                                                <div class="custom-scroll flex-auto">
                                                    <div class="wrapper flex flex-1 flex-col">
                                                        @foreach($wallet->orders as $order)
                                                            @if($order->status  == 'open' || $order->status  == 'pending' || $order->status = 'waiting')
                                                                <div class="px-4 md:px-8 py-3 grid grid-cols-8 gap-2 bg-gray-800 text-white tab--system-row items-center">
                                                                    <div class="text-green text-xs">@if($order->type =='buy') Call @else Put @endif</div>
                                                                    <div class="flex flex-row items-center">
                                                                        <span class="text-white text-xs">{{$order->symbol->description}}</span>
                                                                    </div>
                                                                    <div class="text-red text-xs">{{round($order->amount, 2)}}</div>
                                                                    <div class="text-red text-xs">&euro; {{round($order->symbol_price, 2)}}</div>
                                                                    <div class="text-red text-xs">&euro; {{round($order->order_total, 2)}}</div>
                                                                    <div class="text-red text-xs">&euro; {{round($order->fee, 2)}}</div>
                                                                    <div class="text-red text-xs">{{\Carbon\Carbon::parse($order->created_at)->format('d/m/Y h:i')}}</div>
                                                                    <div class="text-green text-xs">{{$order->status}}</div>
                                                                </div>
                                                            @endif
                                                        @endforeach
                                                    </div>
                                                </div>
                                            </div>
                                        @endif
                                        @if($view_tab == 'filled')
                                            <div class="text-white flex flex-col flex-1 overflow-hidden mt-5 xl:mt-0">
                                                <div class="px-4 md:px-8 py-2 grid grid-cols-8 gap-2 bg-gray-800 text-white trade-history-header text-gray-700 uppercase semibold">
                                                    <div>Side</div>
                                                    <div>Market</div>
                                                    <div>Size</div>
                                                    <div>Filled</div>
                                                    <div>Price</div>
                                                    <div>Fee</div>
                                                    <div>Time</div>
                                                    <div>Status</div>
                                                </div>

                                                <div class="custom-scroll flex-auto">
                                                    <div class="wrapper flex flex-1 flex-col">
                                                        @foreach($wallet->orders as $order)
                                                            @if($order->status  == 'close' || $order->status  == 'cancelled')
                                                                <div class="px-4 md:px-8 py-3 grid grid-cols-8 gap-2 bg-gray-800 text-white tab--system-row items-center">
                                                                    <div class="text-green text-xs">@if($order->type =='buy') Call @else Put @endif</div>
                                                                    <div class="flex flex-row items-center">
                                                                        <span class="text-white text-xs">{{$order->symbol->description}}</span>
                                                                    </div>
                                                                    <div class="text-red text-xs">{{round($order->amount, 2)}}</div>
                                                                    <div class="text-red text-xs">&euro; {{round($order->symbol_price, 2)}}</div>
                                                                    <div class="text-red text-xs">&euro; {{round($order->order_total, 2)}}</div>
                                                                    <div class="text-red text-xs">&euro; {{round($order->fee, 2)}}</div>
                                                                    <div class="text-red text-xs">{{\Carbon\Carbon::parse($order->created_at)->format('d/m/Y h:i')}}</div>
                                                                    <div class="text-green text-xs">{{$order->status}}</div>
                                                                </div>
                                                            @endif
                                                        @endforeach
                                                    </div>
                                                </div>
                                            </div>
                                        @endif

                                        @if($view_tab == 'fees')
                                            <div class="text-white flex flex-col flex-1 overflow-hidden mt-4 md:mt-0">
                                                <div class="px-4 md:px-8 py-2 flex flex-row bg-gray-800 text-white text-xs text-gray-700">
                                                    <div class="text-xl text-white pt-4 border-b border-gray-600 w-full pb-4 mb-4">
                                                        Fees
                                                    </div>
                                                </div>
                                                <div class="custom-scroll">
                                                    <div class="px-4 md:px-8 py-2 pb-5 flex flex-col 2xl:flex-row bg-gray-800 text-white text-xs flex-1 text-gray-700">
                                                        <div class="flex flex-1 flex-col">
                                                            <p class="text-white text-sm">See all our prices</p>
                                                            <p class="text-white opacity-50 text-sm pt-2 pb-3"> We offer five levels of pricing depending on your account tier.</p>

                                                            <div class="md:px-0 py-2 grid grid-cols-6 gap-2 text-white opacity-80 tab--system-row items-center text-sm md:mr-8" style="background:#263543;">
                                                                <div></div>
                                                                <div>BROKERAGE</div>
                                                                <div>CLASSIC</div>
                                                                <div>GOLD</div>
                                                                <div>PLATINUM</div>
                                                                <div>VIP</div>
                                                            </div>
                                                            <div class="md:px-0 py-2 grid grid-cols-6 gap-2 bg-gray-800 text-white tab--system-row items-center b-b border-gray-600 md:mr-8">
                                                                <div>STOCKS</div>
                                                                <div>0.0016%</div>
                                                                <div>0.0008%</div>
                                                                <div>0.0006%</div>
                                                                <div>0.0004%</div>
                                                                <div>0.00002%</div>
                                                            </div>

                                                            <div class="md:px-0 py-2 grid grid-cols-6 gap-2 bg-gray-800 text-white tab--system-row items-center b-b border-gray-600 md:mr-8">
                                                                <div>FOREX</div>
                                                                <div>0.0016%</div>
                                                                <div>0.0008%</div>
                                                                <div>0.0006%</div>
                                                                <div>0.0004%</div>
                                                                <div>0.00002%</div>
                                                            </div>

                                                            <div class="md:px-0 py-2 grid grid-cols-6 gap-2 bg-gray-800 text-white tab--system-row items-center b-b border-gray-600 md:mr-8">
                                                                <div>INDICES</div>
                                                                <div>0.0016%</div>
                                                                <div>0.0008%</div>
                                                                <div>0.0006%</div>
                                                                <div>0.0004%</div>
                                                                <div>0.00002%</div>
                                                            </div>

                                                            <div class="md:px-0 py-2 grid grid-cols-6 gap-2 bg-gray-800 text-white tab--system-row items-center b-b border-gray-600 md:mr-8">
                                                                <div>COMMODITIES</div>
                                                                <div>0.0016%</div>
                                                                <div>0.0008%</div>
                                                                <div>0.0006%</div>
                                                                <div>0.0004%</div>
                                                                <div>0.00002%</div>
                                                            </div>

                                                            <div class="md:px-0 py-1 grid grid-cols-6 gap-2 bg-gray-800 text-white tab--system-row items-center md:mr-8 b-b border-gray-600">
                                                                <div>CRYPTOCURRENCIES</div>
                                                                <div>0.0016%</div>
                                                                <div>0.0008%</div>
                                                                <div>0.0006%</div>
                                                                <div>0.0004%</div>
                                                                <div>0.00002%</div>
                                                            </div>

                                                        </div>
                                                        <div class="2xl:px-8 py-2 flex flex-row bg-gray-800 text-white text-xs pt-10 2xl:pt-0 flex-1 text-gray-700 2xl:border-l border-gray-600" style="border-bottom:none;">
                                                            <div class="flex flex-1 flex-col">
                                                                <p class="text-white text-sm">General Charges</p>

                                                                <p class="text-white opacity-50 text-sm pt-2 pb-3"> We’re fully transparent about our charges, so you’ll always know how much it costs to trade and invest with us.</p>

                                                                <div class="md:px-0 py-2 grid grid-cols-6 gap-2 text-white opacity-80 tab--system-row items-center text-sm" style="background:#263543;">
                                                                    <div></div>
                                                                    <div>BROKERAGE</div>
                                                                    <div>CLASSIC</div>
                                                                    <div>GOLD</div>
                                                                    <div>PLATINUM</div>
                                                                    <div>VIP</div>
                                                                </div>
                                                                <div class="md:px-0 py-2 grid grid-cols-6 gap-2 bg-gray-800 text-white tab--system-row items-center b-b border-gray-600">
                                                                    <div>Custody fees</div>
                                                                    <div class="opacity-60">€5</div>
                                                                    <div class="opacity-60">€5</div>
                                                                    <div class="opacity-60">€5</div>
                                                                    <div class="opacity-60">€5</div>
                                                                    <div class="opacity-60">€5</div>
                                                                </div>
                                                                <div class="md:px-0 py-2 grid grid-cols-6 gap-2 bg-gray-800 text-white tab--system-row items-center b-b border-gray-600">
                                                                    <div>Withdrawal fees</div>
                                                                    <div class="opacity-60">
                                                                        €75 if &lt; €1,000
                                                                        <br>
                                                                        €150 if >€1000
                                                                    </div>
                                                                    <div class="opacity-60">
                                                                        €75 if &lt; €1,000
                                                                        <br>
                                                                        €150 if &gt; €1000
                                                                    </div>
                                                                    <div class="opacity-60">
                                                                        contact representative for special offerings
                                                                    </div>
                                                                    <div class="opacity-60">
                                                                        contact representative for special offerings
                                                                    </div>
                                                                    <div class="opacity-60">
                                                                        contact representative for special offerings
                                                                    </div>
                                                                </div>
                                                                <div class="md:px-0 py-2 grid grid-cols-6 gap-2 bg-gray-800 text-white tab--system-row items-center b-b border-gray-600">
                                                                    <div>Commissions</div>
                                                                    <div class="opacity-60">
                                                                        6% per year
                                                                        (fee will be settled in first week of December)
                                                                    </div>
                                                                    <div class="opacity-60">
                                                                        6% per year
                                                                        (fee will be settled in first week of December)
                                                                    </div>
                                                                    <div class="opacity-60">
                                                                        6% per year
                                                                        (fee will be settled in first week of December)
                                                                    </div>
                                                                    <div class="opacity-60">
                                                                        contact representative for special offerings
                                                                    </div>
                                                                    <div class="opacity-60">
                                                                        contact representative for special offerings
                                                                    </div>
                                                                </div>
                                                                <div class="md:px-0 py-2 grid grid-cols-6 gap-2 bg-gray-800 text-white tab--system-row items-center b-b border-gray-600">
                                                                    <div>Rollover fees</div>
                                                                    <div class="opacity-60">
                                                                        0.1% once a month
                                                                    </div>
                                                                    <div class="opacity-60">
                                                                        0.1% once a month
                                                                    </div>
                                                                    <div class="opacity-60">
                                                                        0.1% once a month
                                                                    </div>
                                                                    <div class="opacity-60">
                                                                        0.1% once a month
                                                                    </div>
                                                                    <div class="opacity-60">
                                                                        contact representative for special offerings
                                                                    </div>
                                                                </div>
                                                                <div class="md:px-0 py-2 pb-2 grid grid-cols-6 gap-2 bg-gray-800 text-white tab--system-row items-center b-b border-gray-600">
                                                                    <div>Inactive account</div>
                                                                    <div class="opacity-60">
                                                                        €89 after 90 days
                                                                    </div>
                                                                    <div class="opacity-60">
                                                                        €89 after 90 days
                                                                    </div>
                                                                    <div class="opacity-60">
                                                                        €89 after 90 days
                                                                    </div>
                                                                    <div class="opacity-60">
                                                                        €89 after 90 days
                                                                    </div>
                                                                    <div class="opacity-60">
                                                                        €89 after 90 days
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        @endif
                                    @endif
                                @endforeach
                            </div>
                        </div>
                    </div>
                </div>
            </div>



            <!-- Mobile Submenu -->
            <div class="flex flex-row xl:hidden footer--submenu">
                <a href="wallet.html" class="flex flex-row flex-auto text-center text-white">Balances</a>
                <a href="turnover.html" class="xl:flex flex-row flex-auto text-center text-white">Turnover</a>
                <a href="deposits.html" class="active xl:flex flex-row flex-auto text-center text-white">Deposits</a>
                <a href="withdraws.html" class="xl:flex flex-row flex-auto text-center text-white">Withdrawals</a>
            </div>

            <!-- Footer -->
            <div class="footer px-3 py-2 border-t border-gray-600 hidden xl:visible" style="border-left:none; border-right:none; border-bottom:none;">
                <div class="text-white bg-gray-900 system-status maintenance">Service Under Maintenance</div>
            </div>
        </div>
    </main>




    <!-- Adding Wallet -->
    <x-jet-dialog-modal wire:model="addingWallet">
        <x-slot name="title">
            {{ __('Add new Wallet') }}
        </x-slot>

        <x-slot name="content">
            <!-- New Name -->
            <div class="col-span-6 sm:col-span-4">
                <x-jet-label for="new_name" value="{{ __('Wallet Name') }}" />
                <x-jet-input id="new_name" type="text" class="mt-1 block w-full" wire:model="new_name" />
                <x-jet-input-error for="new_name" class="mt-2" />
            </div>
            <div class="col-span-6 sm:col-span-4">
                <x-jet-input id="margin_wallet" type="checkbox" class="mt-1" wire:model="margin_wallet" style="float:left;" />
                <x-jet-label for="margin_wallet" value="{{ __('Margin Wallet') }}" />
                <x-jet-input-error for="margin_wallet" class="mt-2" />
            </div>
        </x-slot>

        <x-slot name="footer">
            <x-jet-secondary-button wire:click="$toggle('addingWallet')" wire:loading.attr="disabled">
                {{ __('Cancel') }}
            </x-jet-secondary-button>

            <x-jet-button class="ml-2" wire:click="addWallet" wire:loading.attr="disabled">
                {{ __('add Wallet') }}
            </x-jet-button>
        </x-slot>
    </x-jet-dialog-modal>

    <!-- Rename Wallet -->
    <x-jet-dialog-modal wire:model="renamingWallet">
        <x-slot name="title">
            {{ __('Renaming Wallet') }}
        </x-slot>

        <x-slot name="content">
            <!-- New Name -->
            <div class="col-span-6 sm:col-span-4">
                <x-jet-label for="rename_name" value="{{ __('Wallet Name') }}" />
                <x-jet-input id="rename_name" type="text" class="mt-1 block w-full" wire:model="rename_name" />
                <x-jet-input-error for="rename_name" class="mt-2" />
            </div>
        </x-slot>

        <x-slot name="footer">
            <x-jet-secondary-button wire:click="$toggle('renamingWallet')" wire:loading.attr="disabled">
                {{ __('Cancel') }}
            </x-jet-secondary-button>

            <x-jet-button class="ml-2" wire:click="renameWallet" wire:loading.attr="disabled">
                {{ __('Rename Wallet') }}
            </x-jet-button>
        </x-slot>
    </x-jet-dialog-modal>
</div>
