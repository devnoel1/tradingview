<em class="grid grid-cols-1 px-8 py-4 border-b border-gray-600 bg-gray-800 text-white">Trade History</em>

<div class="px-8 py-2 grid grid-cols-5 gap-1 bg-gray-900 text-white trade-history-header">
    <div>P/L</div>
    <div>Size</div>
    <div>Time</div>
    <div>Status</div>
    <div>Side</div>
</div>
<div class="history--scroll" style="overflow: auto;">
    <div class="wrapper flex flex-1 flex-col max-h-max pb-20">

        @foreach($orders as $order)
            <div
                class="px-8 py-1 grid grid-cols-5 gap-1 bg-gray-900 text-white trade-history-row">
                <div
                    class="@if(($order->symbol->last_value - $order->symbol_price)>0) text-green  @else text-red @endif">{{round(($order->symbol->last_value - $order->symbol_price), 2)}}</div>
                <div class="">{{round($order->amount, 2)}}</div>
                <div
                    class="">{{\Carbon\Carbon::parse($order->created_at)->format('d/m')}}</div>
                <div class="">@if($order->status == 'waiting_sell')
                        waiting @elseif($order->status == 'cancelled') cancel @else {{$order->status}} @endif</div>
                <div
                    class="@if($order->type =='buy')text-green @else text-red @endif">@if($order->type =='buy')
                        put @else call @endif</div>
            </div>
        @endforeach

    </div>
</div>



