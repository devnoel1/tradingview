<x-app-layout>

    <livewire:orders-view/>
</x-app-layout>
