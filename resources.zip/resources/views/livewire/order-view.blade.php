<div class="text-white open-orders flex flex-1 flex-col overflow-hidden bg-gray-800">
    <div class="grid grid-flow-col auto-cols-max justify-between flex items-center px-8 py-4 border-b border-gray-600 bg-gray-800">
        <em class="text-white">Open Orders</em>

        <div class="grid grid-cols-2 gap-0 symbolbuy-second-tab">
            <div class="col-start-1 col-end-1 symbolbuy-tab @if($selectedView == 'open') active @endif" wire:click="setView('open')">Open</div>
            <div class="col-start-2 col-end-2 symbolbuy-tab @if($selectedView == 'fills') active @endif" wire:click="setView('fills')">Fills</div>
        </div>
    </div>

    <div class="px-8 py-2 grid grid-cols-7 gap-0 bg-gray-900 text-white order-header">
        <div></div>
        <div>Size</div>
        <div>Filled</div>
        <div>Price</div>
        <div>Time</div>
        <div>Status</div>
        <div></div>
    </div>

    <div class="custom-scroll">
        <div class="wrapper">
            @foreach($active_wallet->orders as $order)
                @if($order->symbol->id == $active_symbol_id)
                    @if($selectedView == 'open')
                        @if($order->status == 'open' || $order->status == 'pending' || $order->status == 'waiting' || $order->status == 'waiting_sell')
                            <div class="px-8 py-2 grid grid-cols-7 gap-2 bg-gray-900 text-white order-row">
                                <div>
                                    <span class="@if(($order->symbol->last_value - $order->symbol_price)>0) text-green xl:border-l-2 border-green pl-2  @else text-red xl:border-l-2 border-red pl-2 @endif">{{$order->symbol->last_value - $order->symbol_price}}</span>
                                </div>
                                <div>{{$order->amount}}</div>
                                <div>@if($order->status == 'open' || $order->status == 'waiting' || $order->status == 'waiting_sell' ){{$order->amount}} @endif</div>
                                <div>{{$order->symbol_price}}</div>
                                <div>{{\Carbon\Carbon::parse($order->created_at)->format('d/m/Y h:i')}}</div>
                                <div>@if($order->status == 'waiting_sell')waiting @else {{$order->status}} @endif</div>
                                <div>
                                    @if($order->status == 'open')
                                        <button class="inline-flex items-center px-4 py-1 bg-gray-800 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:bg-gray-700 active:bg-gray-900 focus:outline-none focus:border-gray-900 focus:ring focus:ring-gray-300 disabled:opacity-25 transition update-order-status-button" wire:click="sellOrder('{{$order->id}}')">
                                            Close
                                        </button>
                                    @elseif($order->status == 'pending')
                                        <button class="inline-flex items-center px-4 py-1 bg-gray-800 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:bg-gray-700 active:bg-gray-900 focus:outline-none focus:border-gray-900 focus:ring focus:ring-gray-300 disabled:opacity-25 transition update-order-status-button" wire:click="cancelOrder('{{$order->id}}')">
                                            Cancel
                                        </button>
                                    @elseif($order->status == 'waiting')
                                        <button class="inline-flex items-center px-4 py-1 bg-gray-800 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:bg-gray-700 active:bg-gray-900 focus:outline-none focus:border-gray-900 focus:ring focus:ring-gray-300 disabled:opacity-25 transition update-order-status-button" wire:click="cancelOrder('{{$order->id}}')">
                                            Cancel
                                        </button>
                                    @elseif($order->status == 'waiting_sell')
                                        <button class="inline-flex items-center px-4 py-1 bg-gray-800 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:bg-gray-700 active:bg-gray-900 focus:outline-none focus:border-gray-900 focus:ring focus:ring-gray-300 disabled:opacity-25 transition update-order-status-button"  wire:click="cancelOrder('{{$order->id}}')">
                                            Cancel
                                        </button>
                                    @endif
                                </div>
                            </div>
                        @endif
                    @elseif($selectedView =='fills')
                        @if($order->status == 'close' || $order->status == 'cancelled')
                            <div class="px-8 py-2 grid grid-cols-7 gap-2 bg-gray-900 text-white order-row">
                                <div>
                                    <span class="@if(($order->symbol->last_value - $order->symbol_price)>0) text-green xl:border-l-2 border-green pl-2  @else text-red xl:border-l-2 border-red pl-2 @endif">{{$order->symbol->last_value - $order->symbol_price}}</span>
                                </div>
                                <div>{{$order->amount}}</div>
                                <div>@if($order->status == 'closed'){{$order->amount}} @endif</div>
                                <div>{{$order->symbol_price}}</div>
                                <div>{{$order->created_at}}</div>
                                <div>@if($order->status == 'waiting_sell')waiting @else {{$order->status}} @endif</div>
                                <div>
                                </div>
                            </div>
                        @endif
                    @endif
                @endif
            @endforeach
        </div>
    </div>
</div>
