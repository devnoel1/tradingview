<x-app-layout>


    <livewire:wallet-view/>
</x-app-layout>
