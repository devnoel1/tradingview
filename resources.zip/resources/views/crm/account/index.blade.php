@extends('adminlte::page')

@section('title', 'Dashboard')

@section('content_header')
    <h1>CRM - Accounts</h1>
@stop

@section('content')
    <div class="card">
        <div class="card-header">
            <h3 class="card-title">Accounts</h3>
        </div>
        <!-- /.card-header -->
        <div class="card-body">
            <table class="table table-bordered">
                <thead>
                <tr>
                    <th>Account</th>
                    <th>Country</th>
                    <th>Balance</th>
                    <th>Wallet</th>
                    <th style="width: 40px">Identified</th>
                    <th style="width: 40px">Level</th>
                    <th style="width: 60px">Action</th>
                </tr>
                </thead>
                <tbody>

                @foreach ($users as $user)
                <tr>
                    <td><b>{{$user->name}}</b><br/>
                        {{$user->email}}
                    </td>
                    <td>{{$user->userProfile->country}}</td>
                    <td>
                        &euro; {{$user->userProfile->balance}}
                    </td>
                    <td>
                        &euro; 50.000,-
                    </td>
                    <td>
                        @if ($user->userProfile->identified)
                        <span class="badge bg-green">Yes</span>
                        @else
                            <span class="badge bg-danger">No</span>
                        @endif
                    </td>
                    <td>
                        {{ $user->userProfile->level->name }}
                    </td>
                    <td>
                        <div class="btn-group">
                            <a type="button" class="btn btn-info" href="{{route('crm.account.show', ['account' => $user->id])}}">
                                <i class="fas fa-eye"></i>
                            </a>
                            <a type="button" class="btn btn-info" href="{{route('crm.account.edit', ['account' => $user->id])}}"><i class="fas fa-pen"></i></a>
{{--                            <button type="button" class="btn btn-info">--}}
{{--                                <i class="fas fa-pen"></i>--}}
{{--                            </button>--}}
{{--                            <button type="button" class="btn btn-danger">--}}
{{--                                <i class="fas fa-trash"></i>--}}
{{--                            </button>--}}
                        </div>
                    </td>
                </tr>
                @endforeach
                </tbody>
            </table>
        </div>
        <!-- /.card-body -->
        <div class="card-footer clearfix">
{{--            <ul class="pagination pagination-sm m-0 float-right">--}}
{{--                <li class="page-item"><a class="page-link" href="#">«</a></li>--}}
{{--                <li class="page-item"><a class="page-link" href="#">1</a></li>--}}
{{--                <li class="page-item"><a class="page-link" href="#">2</a></li>--}}
{{--                <li class="page-item"><a class="page-link" href="#">3</a></li>--}}
{{--                <li class="page-item"><a class="page-link" href="#">»</a></li>--}}
{{--            </ul>--}}
            {{ $users->links() }}
        </div>
        <a type="button" class="btn btn-info" href="{{route('crm.account.create')}}">
            <i class="fas fa-plus"></i>
        </a>
    </div>

@stop

@section('css')
    <link rel="stylesheet" href="/css/admin_custom.css">
@stop

@section('js')

@stop
