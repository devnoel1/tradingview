

<div>
    <div class="px-3 py-4 2xl:px-6 2xl:py-4 border-b border-gray-600 bg-gray-800">
        <em class="text-white block">Wallet Balance</em>
    </div>
    <div class="border-b border-gray-600 wallet-balance-info">
        <div
            class="grid grid-cols-2 gap-0 text-gray-300 border-b border-gray-600 wallet-balance-info-header px-3 py-3 2xl:px-6 2xl:py-2">
            <div class="col-start-1 col-end-1 text-xs">Asset</div>
            <div class="col-start-2 col-end-2 text-right text-xs">Amount</div>
        </div>

        <div class="px-3 pt-3 pb-3 2xl:px-6 2xl:pt-3 2xl:pb-3">
            <div class="grid grid-cols-2 gap-0 text-white wallet-balance-info-value">
                <div class="col-start-1 col-end-1 text-xs pt-1 pb-1">{{$active_wallet->currency}}</div>
                <div
                    class="col-start-2 col-end-2 walllet-balance-value-value text-right text-xs pt-1 pb-1 font-extrabold">{{round($active_wallet->balance, 2)}}</div>
            </div>
            <div class="grid grid-cols-2 gap-0 text-white wallet-balance-info-value">
                <div class="col-start-1 col-end-1 text-xs pt-1 pb-1">{{$active_symbol}}</div>
                <div
                    class="col-start-2 col-end-2 walllet-balance-value-value text-right text-xs pt-1 pb-1 font-extrabold">{{round($symbol_in_wallet, 4)}}</div>
            </div>
            @if($market_open != true)
                <div class="grid grid-cols-1 gap-0 text-white wallet-balance-info-value">
                    <div class="col-start-1 col-end-1 text-xs pt-1 pb-1"><b>Market closed</b></div>
                </div>
            @endif
        </div>
    </div>
    <div class="border-b border-gray-600 wallet-balance bg-gray-800 px-3 py-4 2xl:px-6 2xl:py-4">
        <em class="text-white block">Order Form</em>
    </div>
    <div class="col-span-2 text-white symbolbuy px-3 pt-4 2xl:px-6 2xl:pt-4">
        <div class="grid grid-cols-2 gap-0 symbolbuy-first-tab">
            <div
                class="col-start-1 col-end-1 symbolbuy-tab call--button text-center @if($selectedType == 'buy') bg-green @endif "
                wire:click="setType('buy')">Call
            </div>
            <div
                class="col-start-2 col-end-2 symbolbuy-tab put--button text-center @if($selectedType == 'sell') bg-red @endif "
                wire:click="setType('sell')">Put
            </div>
        </div>
        <div class="grid grid-cols-3 gap-0 symbolbuy-second-tab border-b border-gray-600 pt-6 text-center">
            <div class="col-start-1 col-end-1 symbolbuy-tab @if($selectedOrderType == 'market')active @endif"
                 wire:click="setOrderType('market')">Market
            </div>
            <div class="col-start-2 col-end-2 symbolbuy-tab @if($selectedOrderType == 'limit')active @endif"
                 wire:click="setOrderType('limit')">Limit
            </div>
            <div class="col-start-3 col-end-3 symbolbuy-tab @if($selectedOrderType == 'stop')active @endif"
                 wire:click="setOrderType('stop')">Stop
            </div>
        </div>

        @if($selectedOrderType == 'market')
            <div class="grid grid-cols-1 gap-0 order-formfield pt-4">
                <div class="col-start-1 col-end-1">
                    @if($selectedType=='buy')
                        <label class="block font-medium text-sm text-gray-400">Amount</label>
                        <div class="pt-2">
                            <div class="amount--container flex items-center gap-0 bg-dark">
                                <span wire:click="setBuyMax()" class="max-button">max</span>
                                <input type="text" placeholder="0" step="0.01" min="0" class="form-input custom-input"
                                       wire:model="price" wire:keydown="updatePrices" wire:click="updatePrices"
                                       wire:keyup="updatePrices">
                                <div class="label">
                                    <sub>{{$active_wallet->currency}}</sub>
                                </div>
                            </div>
                        </div>
                    @elseif($selectedType='sell')
                        <label class="block font-medium text-sm text-gray-400">Amount</label>
                        <div class="pt-2">
                            <div class="amount--container flex items-center gap-0 bg-dark">
                                <span wire:click="setSellMax()" class="max-button">max</span>
                                <input type="text" placeholder="0" step="0.01" min="0" class="form-input custom-input"
                                       wire:model="amount" wire:keydown="updatePrices" wire:click="updatePrices"
                                       wire:keyup="updatePrices">
                                <div class="label">
                                    <sub>{{$active_symbol}}</sub>
                                </div>
                            </div>
                        </div>
                    @endif
                </div>
            </div>
        @endif
        @if($selectedOrderType == 'stop')
            <div class="grid grid-cols-1 gap-0 order-formfield pt-4">
                <div class="col-start-1 col-end-1">
                    <label class="block font-medium text-sm text-gray-400">Stop Price</label>
                    <div class="pt-2">
                        <div class="amount--container flex items-center gap-0 bg-dark">
                            <input type="text" placeholder="0" step="0.01" min="0" class="form-input custom-input"
                                   wire:model="stop" wire:keydown="updatePrices" wire:click="updatePrices">
                            <div class="label">
                                <sub>{{$active_wallet->currency}}</sub>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        @endif
        @if($selectedOrderType == 'limit' || $selectedOrderType == 'stop')
            <div class="grid grid-cols-1 gap-0 order-formfield pt-4">
                <div class="col-start-1 col-end-1">
                    <label class="block font-medium text-sm text-gray-400">Amount</label>
                    <div class="pt-2">
                        <div class="amount--container flex items-center gap-0 bg-dark">
                            @if($selectedType=='buy')
                                <span wire:click="setBuyMax()" class="max-button">max</span>
                            @elseif($selectedType=='sell')
                                <span wire:click="setSellMax()" class="max-button">max</span>
                            @endif
                            <input type="text" placeholder="0" step="0.01" min="0" class="form-input custom-input"
                                   wire:model="amount" wire:keydown="updatePrices" wire:click="updatePrices">
                            <div class="label">
                                <sub>{{$active_symbol}}</sub>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="grid grid-cols-1 gap-0 order-formfield pt-4">
                <div class="col-start-1 col-end-1">
                    <label class="block font-medium text-sm text-gray-400">Limit</label>
                    <div class="pt-2">
                        <div class="amount--container flex items-center gap-0 bg-dark">
                            <input type="text" placeholder="0" step="0.01" min="0" class="form-input custom-input"
                                   wire:model="limit" wire:keydown="updatePrices" wire:click="updatePrices">
                            <div class="label">
                                <sub>{{$active_wallet->currency}}</sub>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        @endif

        <div class="grid grid-cols-1 gap-0 border-t border-gray-600 leverage-field order-formfield pt-3">
            <div class="col-start-1 col-end-1">
                <label class="block font-medium text-sm text-gray-400">Leverage</label>
                <input type="range" min="0" max="100" wire:model="leverage"
                       class="slider rounded-lg overflow-hidden appearance-none bg-gray-400 h-3 w-128" id="myRange">

                <div class="pt-2">
                    <div class="amount--container flex items-center gap-0 bg-dark">
                        <span wire:click="setBuyMax()" class="max-button">max</span>
                        <input type="text" placeholder="0" step="1" min="0" class="form-input custom-input"
                               wire:model="leverage">
                        <div class="label">
                            <sub class="text-lg">%</sub>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="flex border-t-2 order-total-top order-formfield order-total-field pt-4 mt-4">
            <div class="w-1/2 text-xs">Fee ≈</div>
            <div class="w-1/2 text-right text-xs font-extrabold">{{round($order_fee, 2)}} {{$active_wallet->currency}}</div>
        </div>
        <div class="flex order-formfield order-total-field py-2">
            <div class="w-1/2 text-xs">Amount ≈</div>
            <div class="w-1/2 text-right text-xs font-extrabold">{{round($amount, 4)}} {{$active_symbol}}</div>
        </div>
        <div class="flex order-formfield order-total-field">
            <div class="w-1/2 text-xs">Total ≈</div>
            <div class="w-1/2 text-right text-xs font-extrabold">{{round($order_price, 2)}} {{$active_wallet->currency}}</div>
        </div>
        @if($active_wallet->margin && $selectedType == 'buy')
            <div class="flex order-formfield order-total-field">
                <div class="w-1/2 text-xs">Initial margin ≈</div>
                <div
                    class="w-1/2 text-right text-xs font-extrabold">{{round($initial_margin,2 )}} {{$active_wallet->currency}}</div>
            </div>
        @endif
        <div class="grid grid-cols-1 gap-0 order-button mt-5 mb-10">
            @if($order_button_enabled)
                <div
                    class="col-start-1 col-end-1 @if($selectedType == 'buy') bg-green @endif @if($selectedType == 'sell') bg-red @endif place--button text-center"
                    wire:click="placeOrder()">
                    @if($selectedType == 'buy')
                        Place call order
                    @elseif($selectedType == 'sell')
                        Place putt order
                    @endif
                </div>
            @else
                <div class="col-start-1 col-end-1 place--button text-center" style="background-color:grey">
                    @if($selectedType == 'buy')
                        Place call order
                    @elseif($selectedType == 'sell')
                        Place put order
                    @endif
                </div>
            @endif
        </div>
        @if($message or $error)
            <div class="grid grid-cols-4 gap-0 @if($message) bg-green @elseif($error) bg-red @endif text-center"
                 wire:click="closeMessage()">
                <div class="col-start-1 col-end-3">
                    @if($message)
                        {{$message}}
                    @endif
                    @if($error)
                        {{$error}}
                    @endif
                </div>
                <div class="col-start-4 col-end-4">
                    X
                </div>
            </div>
        @endif
    </div>
</div>
