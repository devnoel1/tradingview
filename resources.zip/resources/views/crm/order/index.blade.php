@extends('adminlte::page')

@section('title', 'Dashboard')

@section('content_header')
    <h1>CRM - Orders</h1>
@stop

@section('content')
    <div class="card">
        <div class="card-header">
            <h3 class="card-title">Orders</h3>
        </div>
        <!-- /.card-header -->
        <div class="card-body">
            <table class="table table-bordered">
                <thead>
                <tr>
                    <td></td>
                    <td>ACCOUNT</td>
                    <td>EXCHANGE</td>
                    <td>SYMBOL</td>
                    <td>AMOUNT</td>
                    <td>LIMIT</td>
                    <td>STOP</td>
                    <td>CREATED</td>
                    <td>STATUS</td>
                    <th style="width: 60px">Action</th>
                </tr>
                </thead>
                <tbody>
                @foreach ($orders as $order)
                    <tr>
                        <td>
                            @if($order->type == 'buy')
                                +
                            @else
                                -
                            @endif
                        </td>
                        <td>{{$order->wallet->user->name}}</td>
                        <td>{{$order->symbol->exchange->name}}</td>
                        <td>{{$order->symbol->description}}</td>
                        <td>{{$order->amount}} <span>{{round(((1 - $order->symbol_price / $order->symbol->last_value) * 100),2)}}%</span></td>
                        <td>{{$order->limit_price}}</td>
                        <td>{{$order->stop_price}}</td>
                        <td>{{$order->created_at}}</td>
                        <td>@if($order->status == 'waiting_sell')waiting @else {{$order->status}} @endif</td>
                        <td>
                            <div class="btn-group">
                                <a type="button" class="btn btn-info" href="{{route('crm.order.show', ['order' => $order->id])}}"><i class="fas fa-eye"></i></a>
{{--                                <a type="button" class="btn btn-info" href="{{route('crm.order.edit', ['order' => $order->id])}}"><i class="fas fa-pen"></i></a>--}}
{{--                                <form action="{{ route('crm.order.destroy', ['order' => $order->id]) }}" method="POST">--}}
{{--                                    @method('DELETE')--}}
{{--                                    @csrf--}}
{{--                                    <button type="submit" class="btn btn-danger"><i class="fas fa-trash"></i></button>--}}
{{--                                </form>--}}
                            </div>
                        </td>
                    </tr>
                @endforeach

                </tbody>
            </table>
        </div>
        <!-- /.card-body -->
        <div class="card-footer clearfix">
{{--            <ul class="pagination pagination-sm m-0 float-right">--}}
{{--                <li class="page-item"><a class="page-link" href="#">«</a></li>--}}
{{--                <li class="page-item"><a class="page-link" href="#">1</a></li>--}}
{{--                <li class="page-item"><a class="page-link" href="#">2</a></li>--}}
{{--                <li class="page-item"><a class="page-link" href="#">3</a></li>--}}
{{--                <li class="page-item"><a class="page-link" href="#">»</a></li>--}}
{{--            </ul>--}}
            <div class="d-flex justify-content-center">
            {{ $orders->links() }}
            </div>
        </div>
{{--        <a type="button" class="btn btn-info" href="{{route('crm.level.create')}}">--}}
{{--            <i class="fas fa-plus"></i>--}}
{{--        </a>--}}
    </div>

@stop

@section('css')
    <link rel="stylesheet" href="/css/admin_custom.css">
@stop

@section('js')

@stop
