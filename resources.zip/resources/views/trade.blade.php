<x-app-layout>
    <livewire:trading-view/>
</x-app-layout>
