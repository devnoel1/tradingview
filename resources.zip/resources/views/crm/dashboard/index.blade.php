@extends('adminlte::page')

@section('title', 'Dashboard')

@section('content_header')
    <h1>CRM</h1>
@stop

@section('content')
    <p>Open tasks</p>
    @if(count($identifications) > 0)
    <div class="card">
        <div class="card-header">
            <h3 class="card-title">Identification recieved</h3>
        </div>
        <!-- /.card-header -->
        <div class="card-body">
            <table class="table table-bordered">
                <thead>
                <tr>
                    <th>Account</th>
                    <th>Country</th>
                    <th style="width: 40px">Identified</th>
                    <th style="width: 60px">Action</th>
                </tr>
                </thead>
                <tbody>

                @foreach ($identifications as $identification)
                    <tr>
                        <td><b>{{$identification->user->name}}</b><br/>
                            {{$identification->user->email}}
                        </td>
                        <td>{{$identification->country}}</td>
                        <td>
                            @if ($identification->identified)
                                <span class="badge bg-green">Yes</span>
                            @else
                                <span class="badge bg-danger">No</span>
                            @endif
                        </td>
                        <td>
                            <div class="btn-group">
                                <a type="button" class="btn btn-info" href="{{route('crm.account.identification.show', ['account' => $identification->id])}}">
                                    <i class="fas fa-eye"></i>
                                </a>
                            </div>
                        </td>
                    </tr>
                @endforeach
                </tbody>
            </table>
        </div>
        <!-- /.card-body -->
        <div class="card-footer clearfix">
            {{--            <ul class="pagination pagination-sm m-0 float-right">--}}
            {{--                <li class="page-item"><a class="page-link" href="#">«</a></li>--}}
            {{--                <li class="page-item"><a class="page-link" href="#">1</a></li>--}}
            {{--                <li class="page-item"><a class="page-link" href="#">2</a></li>--}}
            {{--                <li class="page-item"><a class="page-link" href="#">3</a></li>--}}
            {{--                <li class="page-item"><a class="page-link" href="#">»</a></li>--}}
            {{--            </ul>--}}

        </div>
    </div>
    @endif
    @if(count($balance) > 0)
        <div class="card">
            <div class="card-header">
                <h3 class="card-title">Open Balance Transactions</h3>
            </div>
            <!-- /.card-header -->
            <div class="card-body">
                <table class="table table-bordered">
                    <thead>
                    <tr>
                        <th>Account</th>
                        <th>Type</th>
                        <th>Amount</th>
                        <th style="width: 60px">Action</th>
                    </tr>
                    </thead>
                    <tbody>

                    @foreach ($balance as $transaction)
                        <tr>
                            <td><b>{{$transaction->user->name}}</b><br/>
                                {{$transaction->user->email}}
                            </td>
                            <td>{{$transaction->action}}</td>
                            <td>{{$transaction->amount}}</td>
                            <td>
                                <div class="btn-group">
                                    <a type="button" class="btn btn-info" href="{{route('crm.balance.show', ['balance' => $transaction->id])}}">
                                        <i class="fas fa-eye"></i>
                                    </a>
                                </div>
                            </td>
                        </tr>
                    @endforeach
                    </tbody>
                </table>
            </div>
            <!-- /.card-body -->
            <div class="card-footer clearfix">
                {{--            <ul class="pagination pagination-sm m-0 float-right">--}}
                {{--                <li class="page-item"><a class="page-link" href="#">«</a></li>--}}
                {{--                <li class="page-item"><a class="page-link" href="#">1</a></li>--}}
                {{--                <li class="page-item"><a class="page-link" href="#">2</a></li>--}}
                {{--                <li class="page-item"><a class="page-link" href="#">3</a></li>--}}
                {{--                <li class="page-item"><a class="page-link" href="#">»</a></li>--}}
                {{--            </ul>--}}

            </div>
        </div>
    @endif
@stop

@section('css')
    <link rel="stylesheet" href="/css/admin_custom.css">
@stop

@section('js')

@stop
